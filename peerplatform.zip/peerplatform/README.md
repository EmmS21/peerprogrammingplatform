# django-advanced-signup-tutorial
Create Advanced User Sign Up View in Django | Step-by-Step

## Getting Started

This tutorial works on **Python 3+** and Django 2+.

Clone the project by selecting right branch and run following commands:

```
python3 manage.py makemigrations accounts
python3 manage.py migrate
python3 manage.py runserver
```
